package com.example.makeupstore.services;

import com.example.makeupstore.entities.ProductEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ProductService {
    private final List<ProductEntity> products;

    public ProductService() {
        products = new ArrayList<>();
        products.add(new ProductEntity(UUID.randomUUID(), "Rubor Pink", "Rostro", 1000.00, 50));
        products.add(new ProductEntity(UUID.randomUUID(), "Labial Rojo MatTe", "Labios", 150.00, 30));
        products.add(new ProductEntity(UUID.randomUUID(), "Pestañina WaterProof", "Ojos", 500.00, 15));
        products.add(new ProductEntity(UUID.randomUUID(), "Base Lumi-Matte", "Rostro", 1200.00, 10));
        products.add(new ProductEntity(UUID.randomUUID(), "Corrector de Ojeras", "Rostro", 40.00, 100));
        products.add(new ProductEntity(UUID.randomUUID(), "Delineador de Ojos", "Ojos", 80.00, 60));
        products.add(new ProductEntity(UUID.randomUUID(), "Sombra Rosa", "Ojos", 200.00, 25));
        products.add(new ProductEntity(UUID.randomUUID(), "Brillo Labial", "Labios", 900.00, 15));
    }

    public List<ProductEntity> createProduct(ProductEntity newProduct) {
        newProduct.setId(UUID.randomUUID());
        products.add(newProduct);
        return (List<ProductEntity>) newProduct;
    }
    public List<ProductEntity> getAllProducts() {
        return products;
    }

    public Optional<ProductEntity> getProductById(UUID id) {
        return products.stream().filter(product -> product.getId().equals(id)).findFirst();
    }

    public Optional<ProductEntity> updateProduct(UUID id, ProductEntity updatedProduct) {
        Optional<ProductEntity> existingProduct = getProductById(id);

        if (existingProduct.isPresent()) {
            ProductEntity product = existingProduct.get();
            product.setProductName(updatedProduct.getProductName());
            product.setCategory(updatedProduct.getCategory());
            product.setPrice(updatedProduct.getPrice());
            product.setStock(updatedProduct.getStock());
            return Optional.of(product);
        }
        return Optional.empty();
    }

    public boolean deleteProduct(UUID id) {
        return products.removeIf(product -> product.getId().equals(id));
    }


}

